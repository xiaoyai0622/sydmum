<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljes_attachment')." (
  `aid` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `pid` int(10) NOT NULL,
  PRIMARY KEY (`aid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljes_attachment` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljes_appointment')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
)";
if(DB::query($sql,'SILENT')){print('create table `aljes_appointment` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljes_setting')." (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
)";
$sql ="ALTER TABLE ".DB::table('aljes_appointment')." ADD `buid` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add buid succeed!<br>');}
if(DB::query($sql,'SILENT')){print('create table `aljes_setting` succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `subtype` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add subtype succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `subsubtype` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add subsubtype succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljes_position')." (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljes_position` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljes_collection')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljes_collection` succeed!<br>');}
$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('aljes_attestation')." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `gongsiname` varchar(255) NOT NULL,
  `num` bigint(20) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
);";
if(DB::query($sql,'SILENT')){print('create table `aljes_attestation` succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `region3` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add region3 succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `solve` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add solve succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes_region')." ADD `level` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add level succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes_region')." ADD `havechild` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add havechild succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `state` tinyint(3) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add state succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `clientip` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add clientip succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `phone` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add phone succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `qrcode` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add qrcode succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `qq` bigint NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add qq succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `new` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add new succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `lxr` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add lxr succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `tuijian` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add tuijian succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `displayorder` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add displayorder succeed!<br>');}
//
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `topstime` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add topstime succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `topetime` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add topetime succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `tid` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add tid succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes_reflashlog')." ADD `name` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add name succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes_reflashlog')." ADD `title` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add title succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes_toplog')." ADD `title` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add title succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes_toplog')." ADD `name` varchar(255) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add name succeed!<br>');}
$sql ="ALTER TABLE ".DB::table('aljes_toplog')." ADD `endtime` int NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add endtime succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('aljes_toplog')." CHANGE `id` `id` INT( 10 ) NOT NULL AUTO_INCREMENT " ;
if(DB::query($sql,'SILENT')){print('add CHANGE succeed!<br>');}
if(file_exists( DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')&&file_exists( DISCUZ_ROOT . './source/plugin/aljes/template/touch/aljes_index.htm')){
	$pluginid = 'aljes';
	$Hooks = array(
		'forumdisplay_topBar',
	);
	$data = array();
	foreach ($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid . '_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::updateAPIHook($data);
}
echo '<br/>repair succeed';
?>
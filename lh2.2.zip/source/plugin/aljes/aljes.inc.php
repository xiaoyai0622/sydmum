<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$pluginid='aljes';
$_GET=dhtmlspecialchars($_GET);
require_once libfile('function/discuzcode'); 
require_once 'source/plugin/aljes/function/function_core.php';
include_once 'source/function/function_misc.php';
include_once libfile('function/editor');
require_once DISCUZ_ROOT.'source/plugin/aljes/class/qrcode.class.php';
if (file_exists("source/plugin/aljes/template/com/qrcode.php")) {
	if (!file_exists("source/plugin/aljes/images/qrcode/aljes_qrcode.jpg")) {
		include 'source/plugin/aljes/template/com/qrcode.php';
	}
}
if($_GET['act']&&$_GET['act']!='view'&&$_GET['act']!='ask'&&$_GET['act']!='upload'&&$_GET['act']!='mupload'&&$_GET['act']!='mobile_deleteattach'){
	if(!$_G['uid']){
		showmessage(lang('plugin/aljes','aljes_1'), '', array(), array('login' => true));
	}
}
//�û���
if ($_G['uid']) {
    if (!C::t('#aljes#aljes_user')->fetch($_G['uid'])) {
        C::t('#aljes#aljes_user')->insert(array('uid' => $_G['uid'], 'username' => $_G['username'], 'dateline' => TIMESTAMP, 'last' => TIMESTAMP));
    } else {
        C::t('#aljes#aljes_user')->update_last_by_uid($_G['uid']);
    }
}
//�û����ʼ�¼
if (!C::t('#aljes#aljes_log')->fetch(gmdate('Ymd', TIMESTAMP))) {
    C::t('#aljes#aljes_log')->insert(array('day' => gmdate('Ymd', TIMESTAMP), 'views' => 1));
} else {
    C::t('#aljes#aljes_log')->update_views_by_day(gmdate('Ymd', TIMESTAMP));
}
$config = $_G['cache']['plugin']['aljes'];
$aljes_seo = dunserialize($_G['setting']['aljes_seo']);
$settings=C::t('#aljes#aljes_setting')->range();
if($settings['iswatermark']['value']){
	require_once DISCUZ_ROOT.'source/plugin/aljes/class/class_image.php';
	$image = new aljbd_image;
}
$typelist = explode ("\n", str_replace ("\r", "", $config ['pinpai']));
foreach($typelist as $key=>$value){
	$arr=explode('=',$value);
	$types[$arr[0]]=$arr[1];
}
$zufangtype = $types;
$new_list = explode ("\n", str_replace ("\r", "", $config ['new']));
foreach($new_list as $key=>$value){
	$new_arr=explode('=',$value);
	$new_types[$new_arr[0]]=$new_arr[1];
}
$paylist = explode ("\n", str_replace ("\r", "", $config ['jg']));
foreach($paylist as $key=>$value){
	$arr=explode('=',$value);
	$pay_types[$arr[0]]=$arr[1];
}
$list_daohang=explode('|',$config['list_daohang']);
$regions = C::t('#aljes#aljes_region')->range();

$shengming=str_replace ("{sitename}", $_G['setting']['bbname'], $config ['shengming']);
$_G['setting']['switchwidthauto'] = 0;
$_G['setting']['allowwidthauto'] = 1;
$wanted_list = explode ("\n", str_replace ("\r", "", $config ['gongqiu']));
foreach($wanted_list as $key=>$value){
	$new_arr=explode('=',$value);
	$wanted_types[$new_arr[0]]=$new_arr[1];
}
//$wanted = array(1=> lang('plugin/aljes','aljes_11'), 2=> lang('plugin/aljes','aljes_12'));
$pos_all = C::t('#aljes#aljes_position')->range();
if($_GET['act'] == 'user'){
	include template('aljes:user');	
}else if($_GET['act']=='appointment'){
	$user=C::t('#aljes#aljes')->fetch($_GET['lid']);
	if (submitcheck('submit')) {
		if (empty($_GET['dateline'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('".lang('plugin/aljes','Time_must_choose')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','Time_must_choose'));
			}
        }
		if (empty($_GET['contact_person'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('".lang('plugin/aljes','Contacts_must_be_filled_out')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','Contacts_must_be_filled_out'));
			}
        }
		if (empty($_GET['tel'])) {
			if($_G['mobile']){
				echo "<script>parent.tips('".lang('plugin/aljes','Phone_number_to_fill_in')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','Phone_number_to_fill_in'));
			}
        }
		
		C::t('#aljes#aljes_appointment')->insert(array(
			'lid'=>$_GET['lid'],
			'uid'=>$_G['uid'],
			'name'=>$_G['username'],
			'dateline'=>$_GET['dateline'],
			'tel'=>$_GET['tel'],
			'contact_person'=>$_GET['contact_person'],
			'message'=>$_GET['message'],
			'sex'=>$_GET['sex'],
			'title'=>$user['title'],
			'timestamp'=>TIMESTAMP,
		));
		notification_add($user['uid'], 'system',lang('plugin/aljes','notification_add_yuyue'));
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".lang('plugin/aljes','Appointment_success')."',function(){parent.location.href='plugin.php?id=aljes&act=view&lid=".$_GET['lid']."';});</script>";
			exit;
		}else{
			echo '<script>parent.showDialog("'.lang('plugin/aljes','Appointment_success').'","right","",function(){parent.location.href=parent.location.href},0)</script>';
			exit;
		}
	}else{
		if(!$_G['uid']){
			showmessage(lang('plugin/aljes','aljes_1'), '', array(), array('login' => true));
		}
		if($user['uid'] == $_G['uid']){
			showmessage(lang('plugin/aljes','Can_not_apply_for'));
		}
		include template('aljes:appointment');
	}
	
}else if($_GET['act'] == 'appointment_list'){
	if(!$_G['uid']){
		showmessage(lang('plugin/aljes','aljes_1'), '', array(), array('login' => true));
	}
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    $num = DB::result_first('select count(*) from %t where uid=%d',array('aljes_appointment',$_G['uid']));
    $start = ($currpage - 1) * $perpage;

    $logs = DB::fetch_all('select * from %t where uid=%d limit %d,%d',array('aljes_appointment',$_G['uid'],$start,$perpage));
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljes&act=appointment_list', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljes_seo['appointment']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['appointment']);
	}
	include template('aljes:appointment_list');
} else if ($_GET['act'] == 'appointment_del') {
	$user=C::t('#aljes#aljes_appointment')->fetch($_GET['cid']);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		showmessage(lang('plugin/aljes','aljes_8'));
	}
    C::t('#aljes#aljes_appointment')->delete($_GET['cid']);
    showmessage(lang('plugin/aljes','aljes_7'), 'plugin.php?id=aljes&act=appointment_list');
}else if ($_GET['act'] == 'appointment_state') {
	$user=C::t('#aljes#aljes_appointment')->fetch($_GET['cid']);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		showmessage(lang('plugin/aljes','aljes_8'));
	}
    C::t('#aljes#aljes_appointment')->update_state_by_id($_GET['cid']);
    showmessage(lang('plugin/aljes','aljes_5'), 'plugin.php?id=aljes&act=appointment_list');
}else if ($_GET['act'] == 'getpos') {
    if ($_GET['rid']) {
        $rs = C::t('#aljes#aljes_position')->fetch_all_by_upid($_GET['rid']);
    }
    include template('aljes:getpos');
}else if ($_GET['act'] == 'getpos1') {
    if ($_GET['upid']) {
        $rlist = C::t('#aljes#aljes_position')->fetch_all_by_upid($_GET['upid']);
    }
	
    include template('aljes:getpos1');
}else if($_GET['act']=='admingetregion'){
	if($_GET['upid']){
		$rlist=C::t('#aljes#aljes_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljes:admingetregion');
}else if($_GET['act']=='admingetregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljes#aljes_region')->fetch_all_by_upid_sys($_GET['upid']);
	}
	include template('aljes:admingetregion1');
}else if($_GET['act'] == 'solve'){
	if (file_exists("source/plugin/aljes/template/com/solve.php")) {
        include 'source/plugin/aljes/template/com/solve.php';
    }
}else if($_GET['act'] == 'collection'){
	if(!$_G['uid']){
		showmessage(lang('plugin/aljes','aljes_1'), '', array(), array('login' => true));
	}
	if (empty($_GET['lid'])) {
        showmessage(lang('plugin/aljes','aljes_6'));
    }
	C::t('#aljes#aljes_collection')->insert(array(
		'lid'=>$_GET['lid'],
		'uid'=>$_G['uid'],
		'dateline'=>TIMESTAMP,
	));
	showmessage(lang('plugin/aljes','The_success_of'),'plugin.php?id=aljes&act=view&lid='.$_GET['lid']);
}else if($_GET['act'] == 'collection_list'){
	if(!$_G['uid']){
		showmessage(lang('plugin/aljes','aljes_1'), '', array(), array('login' => true));
	}
	$currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    $num = DB::result_first('select count(*) from %t where uid=%d',array('aljes_collection',$_G['uid']));
    $start = ($currpage - 1) * $perpage;

    $logs = DB::fetch_all('select * from %t where uid=%d limit %d,%d',array('aljes_collection',$_G['uid'],$start,$perpage));
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljes&act=collection_list', 0, 11, false, false);
	include template('aljes:collection_list');
} else if ($_GET['act'] == 'collection_del') {
	$user=C::t('#aljes#aljes_collection')->fetch($_GET['cid']);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		showmessage(lang('plugin/aljes','aljes_8'));
	}
    C::t('#aljes#aljes_collection')->delete($_GET['cid']);
    showmessage(lang('plugin/aljes','aljes_7'), 'plugin.php?id=aljes&act=collection_list');
}else if($_GET['act'] == 'attes'){
	$r_pay=explode('|',$config['r_pay']);
	if (file_exists("source/plugin/aljes/template/com/attes.php")) {
        include 'source/plugin/aljes/template/com/attes.php';
    }	
}else if ($_GET['act'] == 'post') {
    if (submitcheck('formhash')) {
        if (empty($_GET['title'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljes','aljes_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','aljes_2'));
			}
        }
		if (empty($_GET['zufangtype']) && $settings['isposttype']['value']) {
			if($_GET['sj']){
				echo "<script>parent.tips('&#20998;&#31867;&#24517;&#39035;&#36873;&#25321;&#65281;','');</script>";
				exit;
			}else{
				showerror('&#20998;&#31867;&#24517;&#39035;&#36873;&#25321;&#65281;');
			}
        }
		if (empty($_GET['region'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljes','aljes_24')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','aljes_24'));
			}
        }
		if (empty($_GET['contact'])) {
			if($_GET['sj']){
				echo "<script>parent.tips('".lang('plugin/aljes','aljes_25')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','aljes_25'));
			}
        }
		if($settings['isnewupload']['value']){
			if($_GET['sj']){
				for ($i = 1; $i <= 8; $i++) {
					$pic = 'pic' . $i;
					$_FILES[$pic]['name'] = $_FILES['pic']['name'][$i-1];
					$_FILES[$pic]['tmp_name'] = $_FILES['pic']['tmp_name'][$i-1];
					$_FILES[$pic]['size'] = $_FILES['pic']['size'][$i-1];
					if ($_FILES[$pic]['tmp_name']) {
						$picname = $_FILES[$pic]['name'];
						$picsize = $_FILES[$pic]['size'];
						if ($picsize/1024>$config['img_size']) {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljes','aljes_26').$config['img_size'].'K'."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljes','aljes_26').$config['img_size'].'K');
							}
						}
						if ($picname != "") {
							$type = strtolower(strrchr($picname, '.'));
							if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
								if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
									echo "<script>parent.tips('".lang('plugin/aljes','aljes_3')."','');</script>";
									exit;
								}else{
									showerror(lang('plugin/aljes','aljes_3'));
								}
							}
							$rand = rand(100, 999);
							$pics = date("YmdHis") . $rand . $type;
							$img_dir = 'source/plugin/aljes/images/logo/';
							if (!is_dir($img_dir)) {
								mkdir($img_dir);
							}
							$$pic = $img_dir . $pics;
							if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
								$imageinfo = getimagesize($$pic);
								if($settings['iswatermark']['value']){
									$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
								}
								$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
								$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

								$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
								$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
								$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
								$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

								img2thumb($$pic, $$pic . '.140x100.jpg', $w140, $h100);
								img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
								img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
								@unlink($_FILES[$pic]['tmp_name']);
							}
							
						}
					}
				}
			}else{
				$aids = addslashes($_GET['aid']);
				if($aids){
					if($aids){
						$attachments = DB::fetch_all('select * from %t where aid in (%i)',array('aljes_attachment',$aids));
					}
					$pic = 1;
					foreach($attachments as $i => $attach){
						$c = $i+1;
						if($i>8){
							break;
						}
						$pic = 'pic' . $c;
						$$pic = $attach['pic'];
					}
				}
			}
		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($_FILES[$pic]['tmp_name']) {
					$picname = $_FILES[$pic]['name'];
					$picsize = $_FILES[$pic]['size'];
					if ($picsize/1024>$config['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljes','aljes_26').$config['img_size'].'K'."','');</script>";
							exit;
						}else{
							showerror(lang('plugin/aljes','aljes_26').$config['img_size'].'K');
						}
					}
					if ($picname != "") {
						$type = strtolower(strrchr($picname, '.'));
						if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljes','aljes_3')."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljes','aljes_3'));
							}
						}
						$rand = rand(100, 999);
						$pics = date("YmdHis") . $rand . $type;
						$img_dir = 'source/plugin/aljes/images/logo/';
						if (!is_dir($img_dir)) {
							mkdir($img_dir);
						}
						$$pic = $img_dir . $pics;
						if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
							$imageinfo = getimagesize($$pic);
							if($settings['iswatermark']['value']){
								$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
							}
							$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
							$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

							$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
							$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
							$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
							$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

							img2thumb($$pic, $$pic . '.140x100.jpg', $w140, $h100);
							img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
							img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
							@unlink($_FILES[$pic]['tmp_name']);
						}
						
					}
				}
			}
		}
		if($config['isreview'] && file_exists("source/plugin/aljes/template/com/admin.php") && !in_array($_G['groupid'],unserialize($config['m_groups']))){
			$state=1;
		}	
        $insertarray = array(
            'wanted' => $_GET['wanted'],
            'title' => $_GET['title'],
            'zufangtype' => $_GET['zufangtype'],
            'subtype' => $_GET['subtype'],
            'subsubtype' => $_GET['subsubtype'],
            'qq' => $_GET['qq'],
            'new' => $_GET['new'],
            'zujin' => $_GET['zujin'],
            'content' => $_GET['content'],
            'lxr' => $_GET['lxr'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'region3' => $_GET['region3'],
            'contact' => $_GET['contact'],
            'phone' =>  $_G['mobile'],
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'addtime' => TIMESTAMP,
            'updatetime' => TIMESTAMP,
			'state' =>  $state,
			'clientip' => $_G['clientip'],
        );
        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
            if ($$pic) {
                $insertarray[$pic] = $$pic;
            }
        }
		if (file_exists("source/plugin/aljes/template/com/release.php") && $config['releaseextcredit']) {
			include 'source/plugin/aljes/template/com/release.php';
		}
        $insertid = C::t('#aljes#aljes')->insert($insertarray, true);
		if($settings['isnewupload']['value']){
			if ($_G['mobile']){
				for ($i = 1; $i <= 8; $i++) {
					$pic = 'pic' . $i;
					if ($$pic) {
						C::t('#aljes#aljes_attachment') -> insert(array('pic' => $$pic,'pid' => $insertid),true);
					}
				}
			}else{
				foreach($attachments as $attach){
					$updatearray['pid'] = $insertid;
					$updatearray['pic'] = $attach['pic'];
					C::t('#aljes#aljes_attachment') -> update($attach['aid'],$updatearray);
				}
			}
		}
		if ((file_exists("source/plugin/aljes/template/com/tongbu.php") && !$config['isreview']) || (file_exists("source/plugin/aljes/template/com/tongbu.php") && in_array($_G['groupid'],unserialize($config['m_groups'])))) {
			include 'source/plugin/aljes/template/com/tongbu.php';
		}
		
        C::t('#aljes#aljes_user')->update_count_by_uid($_G['uid']);
		if(!in_array($_G['groupid'],unserialize($config['m_groups'])) && $config['isreview']){
			if($_GET['sj']){
				echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljes','To_examine'))."',function(){parent.location.href='plugin.php?id=aljes&act=view&lid=".$insertid."';});</script>";
			}else{
				showmsg(str_replace('\\','',lang('plugin/aljes','To_examine')), 2, $insertid);
			}
		}else{
			if($_GET['sj']){
				echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljes','aljes_4'))."',function(){parent.location.href='plugin.php?id=aljes&act=view&lid=".$insertid."';});</script>";
			}else{
				showmsg(str_replace('\\','',lang('plugin/aljes','aljes_4')), 2, $insertid);
			}
		}
		
    } else {
		if(!$_G['uid']){
			showmessage(lang('plugin/aljes','aljes_1'), '', array(), array('login' => true));
		}
		//���������û���
		if(!in_array($_G['groupid'],unserialize($config['lj_groups']))){
				showmessage($config['lj_tsy']);
		}
		if (file_exists("source/plugin/aljes/template/com/release.php") && $config['releaseextcredit']) {
			if (getuserprofile('extcredits' . $config['releaseextcredit']) < $config['releasepay']) {
				showmessage($_G['setting']['extcredits'][$config['releaseextcredit']]['title'] . lang('plugin/aljes','top_1'));
			}
		}
		$pos = C::t('#aljes#aljes_position')->fetch_all_by_upid(0);
        $rs = C::t('#aljes#aljes_region')->fetch_all_by_upid(0);
		if($settings['isnewupload']['value']){
			require_once libfile('function/upload');
			$swfconfig = getuploadconfig($_G['uid'], 0, false);
		}
		$navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljes_seo['post']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['post']);
		}
		include template('aljes:post');
    }
} else if ($_GET['act'] == 'edit') {
    if (submitcheck('formhash')) {
        if (empty($_GET['title'])) {
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljes','aljes_2')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','aljes_2'));
			}
            
        }
		if (empty($_GET['zufangtype']) && $settings['isposttype']['value']) {
			if($_GET['sj']){
				echo "<script>parent.tips('&#20998;&#31867;&#24517;&#39035;&#36873;&#25321;&#65281;','');</script>";
				exit;
			}else{
				showerror('&#20998;&#31867;&#24517;&#39035;&#36873;&#25321;&#65281;');
			}
        }
		$lid = intval($_GET['lid']);
		if(empty($lid)){
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljes','edittips')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','edittips'));
			}
		}
		$lp = C::t('#aljes#aljes') -> fetch($lid);
		if($settings['isnewupload']['value']){//�µ�ͼƬ�ϴ���ʽ
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){//�ֻ���
				if($lp['pic1']||$lp['pic2']||$lp['pic3']||$lp['pic4']||$lp['pic5']||$lp['pic6']||$lp['pic7']||$lp['pic8']){
					foreach($_FILES['pic']['name'] as $fk => $fv){
						for ($i = 1; $i <= 8; $i++) {
							$pic = 'pic' . $i;
							if($lp[$pic] || in_array($i-1,$fc)){
								continue;
							}
							if($_FILES['pic']['name'][$fk]){
								$_FILES['pic']['name'][$i-1] = $_FILES['pic']['name'][$fk];unset($_FILES['pic']['name'][$fk]);
								$_FILES['pic']['tmp_name'][$i-1] = $_FILES['pic']['tmp_name'][$fk];unset($_FILES['pic']['tmp_name'][$fk]);
								$_FILES['pic']['size'][$i-1] = $_FILES['pic']['size'][$fk];unset($_FILES['pic']['size'][$fk]);
								$_FILES['pic']['type'][$i-1] = $_FILES['pic']['type'][$fk];unset($_FILES['pic']['type'][$fk]);
								$_FILES['pic']['error'][$i-1] = $_FILES['pic']['error'][$fk];unset($_FILES['pic']['error'][$fk]);
							}
							unset($fc);
							break;
							
						}
					}
				}
				for ($i = 1; $i <= 8; $i++) {
					$pic = 'pic' . $i;
					$_FILES[$pic]['name'] = $_FILES['pic']['name'][$i-1];
					$_FILES[$pic]['tmp_name'] = $_FILES['pic']['tmp_name'][$i-1];
					$_FILES[$pic]['size'] = $_FILES['pic']['size'][$i-1];
					if ($_FILES[$pic]['tmp_name']) {
						$picname = $_FILES[$pic]['name'];
						$picsize = $_FILES[$pic]['size'];
						if ($picsize/1024>$config['img_size']) {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljes','aljes_26').$config['img_size'].'K'."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljes','aljes_26').$config['img_size'].'K');
							}
							
						}
						if ($picname != "") {
							$type = strtolower(strrchr($picname, '.'));
							if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
								if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
									echo "<script>parent.tips('".lang('plugin/aljes','aljes_3')."','');</script>";
									exit;
								}else{
									showerror(lang('plugin/aljes','aljes_3'));
								}
								
							}
							$rand = rand(100, 999);
							$pics = date("YmdHis") . $rand . $type;
							$img_dir = 'source/plugin/aljes/images/logo/';
							if (!is_dir($img_dir)) {
								mkdir($img_dir);
							}
							$$pic = $img_dir . $pics;
							if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
								$imageinfo = getimagesize($$pic);
								if($settings['iswatermark']['value']){
									$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
								}
								$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
								$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

								$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
								$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
								$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
								$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

								img2thumb($$pic, $$pic . '.140x100.jpg', $w140, $h100);
								img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
								img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
								@unlink($_FILES[$pic]['tmp_name']);
							}
						}
					}
				}
			}else{//PC
				$aids = addslashes($_GET['aid']);
				if($aids){
					$attachments = DB::fetch_all('select * from %t where aid in (%i)',array('aljes_attachment',$aids));
				}
				$pic = 1;
				foreach($attachments as $i => $attach){
					$c = $i+1;
					if($i>8){
						break;
					}
					$pic = 'pic' . $c;
					$$pic = $attach['pic'];
				}
			}
		}else{
			for ($i = 1; $i <= 8; $i++) {
				$pic = 'pic' . $i;
				if ($_FILES[$pic]['tmp_name']) {
					$picname = $_FILES[$pic]['name'];
					$picsize = $_FILES[$pic]['size'];
					if ($picsize/1024>$config['img_size']) {
						if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
							echo "<script>parent.tips('".lang('plugin/aljes','aljes_26').$config['img_size'].'K'."','');</script>";
							exit;
						}else{
							showerror(lang('plugin/aljes','aljes_26').$config['img_size'].'K');
						}
						
					}
					if ($picname != "") {
						$type = strtolower(strrchr($picname, '.'));
						if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
							if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
								echo "<script>parent.tips('".lang('plugin/aljes','aljes_3')."','');</script>";
								exit;
							}else{
								showerror(lang('plugin/aljes','aljes_3'));
							}
							
						}
						$rand = rand(100, 999);
						$pics = date("YmdHis") . $rand . $type;
						$img_dir = 'source/plugin/aljes/images/logo/';
						if (!is_dir($img_dir)) {
							mkdir($img_dir);
						}
						$$pic = $img_dir . $pics;
						if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
							$imageinfo = getimagesize($$pic);
							if($settings['iswatermark']['value']){
								$image->Watermark(DISCUZ_ROOT.'./'.$$pic,'', 'forum');
							}
							$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
							$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;

							$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
							$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
							$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
							$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

							img2thumb($$pic, $$pic . '.140x100.jpg', $w140, $h100);
							img2thumb($$pic, $$pic . '.64x64.jpg', $w64, $h64);
							img2thumb($$pic, $$pic . '.640x480.jpg', $w640, $h480);
							@unlink($_FILES[$pic]['tmp_name']);
						}
					}
				}
			}
		}


        $insertarray = array(
            'wanted' => $_GET['wanted'],
            'title' => $_GET['title'],
            'zufangtype' => $_GET['zufangtype'],
			'subtype' => $_GET['subtype'],
            'subsubtype' => $_GET['subsubtype'],
            'qq' => $_GET['qq'],
            'new' => $_GET['new'],
            'lxr' => $_GET['lxr'],
            'zujin' => $_GET['zujin'],
            'content' => $_GET['content'],
            'region3' => $_GET['region3'],
            'region' => $_GET['region'],
            'region1' => $_GET['region1'],
            'region2' => $_GET['region2'],
            'contact' => $_GET['contact'],
            
            
            'updatetime' => TIMESTAMP,
        );
        for ($i = 1; $i <= 8; $i++) {
            $pic = 'pic' . $i;
            if ($$pic) {
                if (empty($$pic)) {
                    $$pic = file_exists($_GET[$pic])?$_GET[$pic]:'';
                }
                $insertarray[$pic] = $$pic;
            }
			if(!file_exists($lp[$pic]) && empty($$pic)){//ͼƬΪ���ж�
				$insertarray[$pic]='';
			}

        }
		//debug($insertarray);
        C::t('#aljes#aljes')->update($_GET['lid'], $insertarray);
		if($settings['isnewupload']['value']){//��ͼ
			if ($_G['mobile']){
				for ($i = 1; $i <= 8; $i++) {
					$pic = 'pic' . $i;
					if ($$pic) {
						C::t('#aljes#aljes_attachment') -> insert(array('pic' => $$pic,'pid' => $_GET['lid']),true);
					}
				}
			}else{
				foreach($attachments as $attach){
					$updatearray['pid'] = $_GET['lid'];
					$updatearray['pic'] = $attach['pic'];
					C::t('#aljes#aljes_attachment') -> update($attach['aid'],$updatearray);
				}
			}
		}
        C::t('#aljes#aljes_user')->update_updatecount_by_uid($_G['uid']);
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljes','aljes_5'))."',function(){parent.location.href='plugin.php?id=aljes&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljes','aljes_5')), 2, $_GET['lid']);
		}
        
    } else {
        $rs = C::t('#aljes#aljes_region')->fetch_all_by_upid(0);
        $lp = C::t('#aljes#aljes')->fetch($_GET['lid']);
		if($lp['uid']!=$_G['uid']&&$_G['groupid']!=1){
			showmessage(lang('plugin/aljesf','aljes_8'));
		}
        $ps = explode(',', $lp['peizhi']);
        if ($lp['region']) {
            $rrs = C::t('#aljes#aljes_region')->fetch_all_by_upid($lp['region']);
        }
		$pos = C::t('#aljes#aljes_position')->fetch_all_by_upid(0);
		//��ͼ s
		if($settings['isnewupload']['value']){//��ͼ
			$lid = intval($_GET['lid']);
			if($lid){
				$attachments = DB::fetch_all('select * from %t where pid = %d',array('aljes_attachment',$lid));
				
				foreach($attachments as $at){
					$taids[] = $at['aid'];
				}
				$taids = implode(',',$taids);
				$lp = C::t('#aljes#aljes')->fetch($lid);
			}
			
			if($settings['isnewupload']['value']){
				require_once libfile('function/upload');
				$swfconfig = getuploadconfig($_G['uid'], 0, false);
			}
		}
		//��ͼ e
        $navtitle = $config['title'];
		$metakeywords = $config['keywords'];
		$metadescription = $config['description'];
		if($aljes_seo['edit']['seotitle']){
			$seodata = array('bbname' => $_G['setting']['bbname']);
			list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['edit']);
		}
		include template('aljes:post');
    }
} else if ($_GET['act'] == 'reflash') {
    if (file_exists("source/plugin/aljes/template/com/reflash.php")) {
        include 'source/plugin/aljes/template/com/reflash.php';
    }
} else if ($_GET['act'] == 'top') {
    if (file_exists("source/plugin/aljes/template/com/top.php")) {
        include 'source/plugin/aljes/template/com/top.php';
    }
} else if ($_GET['act'] == 'view') {
    if (empty($_GET['lid'])) {
        showmessage(lang('plugin/aljes','aljes_6'));
    }
    C::t('#aljes#aljes')->update_views_by_id($_GET['lid']);
    $pics = array('pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6', 'pic7', 'pic8');
    $regions = C::t('#aljes#aljes_region')->range();
    $lp = C::t('#aljes#aljes')->fetch($_GET['lid']);
	
	if (file_exists("source/plugin/aljes/template/com/qrcode.php")) {
		if(!file_exists('source/plugin/aljes/images/qrcode/'.$lp['qrcode'])||!$lp['qrcode']){
			$file = dgmdate(TIMESTAMP, 'YmdHis').random(18).'.jpg';	 QRcode::png($_G['siteurl'].'plugin.php?id=aljes&act=view&lid='.$_GET['lid'], 'source/plugin/aljes/images/qrcode/'.$file, QR_MODE_STRUCTURE, 8);
			DB::update('aljes', array('qrcode'=>$file), "id=".$_GET['lid']);
		}
	}
    $lp = dhtmlspecialchars($lp);
	
	if($config['isyouke']){
		$tel=hidtel($lp['contact']);
	}
	$cod=$regions[$lp['region']]['subject'].$regions[$lp['region1']]['subject'].$regions[$lp['region2']]['subject'].$lp['region3'];
	if($_G['charset']=='gbk'){
		$cod=diconv($cod,'gbk','utf-8');
	}
	$url=urlencode($cod);
	$qita = DB::fetch_all("SELECT * FROM ".DB::table('aljes')." where state=0 and uid=".$lp[uid]." ORDER BY id desc limit 0,".$config['qitanum']);
	foreach($qita as $k=>$v){
		$qita[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	$qita_all=DB::fetch_all('select * from %t where zufangtype = %d or subtype=%d or subsubtype=%d limit 0,6',array('aljes',$lp['zufangtype'],$lp['subtype'],$lp['subsubtype']));
	$commentlist=C::t('#aljes#aljes_comment')->fetch_all_by_upid(0,$_GET['lid']);
	$commentlist=dhtmlspecialchars($commentlist);
    $navtitle = $lp['title'] . '-' . $config['title'];
    $metakeywords = $lp['title'];
    $metadescription = $lp['title'];
	if($aljes_seo['view']['seotitle']){
		if($lp['region']){
			$title=$regions[$lp['region']]['subject'];
			$title1 = $title;
		}
		if($lp['region1']){
			$title=$regions[$lp['region1']]['subject'];
			$title2=$title; 
			
		}
		if($lp['region2']){
			$title=$regions[$lp['region2']]['subject'];
			$title3=$title;
		}
		
		if($lp['zufangtype']){
			$cat=$pos_all[$lp['zufangtype']]['subject'];
		}
		if($lp['subtype']){
			$cat1=$pos_all[$lp['subtype']]['subject'];
		}
		if($lp['subsubtype']){
			$cat2=$pos_all[$lp['subsubtype']]['subject'];
		}
		$seodata = array('bbname' => $_G['setting']['bbname'],'subject'=>$lp['title'],'message'=>cutstr(stripBBCode(strip_tags(preg_replace('/\<img.*?\>/is', '', $lp['content']))),80,''),'cat'=>$cat,'cat1'=>$cat1,'cat2'=>$cat2,'new'=>$new_types[$lp['new']],'pay'=>$lp['zujin'].lang('plugin/aljes','yuan'),'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['view']);
	}
	if($config['template_all'] == '2'){
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
			include template('aljes:58/aljes_view');
		} else {
			include template('diy:aljes_view', null, 'source/plugin/aljes/template/58');
		}
	}else{
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
			include template('aljes:aljes_view');
		} else {
			include template('diy:aljes_view', null, 'source/plugin/aljes/template/');
		}
	}
	
    
} else if ($_GET['act'] == 'delete') {
	$user=C::t('#aljes#aljes')->fetch($_GET['lid']);
	if($user['uid']!=$_G['uid']&&$_G['groupid']!=1){
		showmessage(lang('plugin/aljes','aljes_8'));
	}
	for ($i = 1; $i <= 8; $i++) {
		$pic = 'pic' . $i;
		if ($user[$pic]) {
			unlink($user[$pic]);
			unlink($user[$pic].'.64x64.jpg');
			unlink($user[$pic].'.640x480.jpg');
		}
	}
	if($user['tid']){
		DB::update('forum_post', array('invisible'=>'-1'), "tid=".$user['tid']);
		DB::update('forum_thread', array('displayorder'=>'-1'), "tid=".$user['tid']);
	}
    C::t('#aljes#aljes')->delete($_GET['lid']);
    showmessage(lang('plugin/aljes','aljes_7'), 'plugin.php?id=aljes&act=member');
}else if($_GET['act'] == 'ask'){
	
	if(submitcheck('formhash')){
		if (empty($_G['uid'])) {
			//showerror(lang('plugin/aljes','aljes_1'));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljes','aljes_1')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','aljes_1'));
			}
		}
		if (empty($_GET['message'])) {
			//showerror(lang('plugin/aljes','aljes_9'));
			if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
				echo "<script>parent.tips('".lang('plugin/aljes','aljes_9')."','');</script>";
				exit;
			}else{
				showerror(lang('plugin/aljes','aljes_9'));
			}
		}
		$insertarray=array(
			'content'=>$_GET['message'],	
			'uid'=>$_G['uid'],	
			'username'=>$_G['username'],	
			'lid'=>$_GET['lid'],
			'dateline'=>TIMESTAMP,
		);
		C::t('#aljes#aljes_comment')->insert($insertarray);
		if($config['is_ping']){
			$lp=C::t('#aljes#aljes')->fetch($_GET['lid']);
			notification_add($lp['uid'], 'system',lang('plugin/aljes','aljes_27').' <a target="_blank" href="plugin.php?id=aljes&act=view&lid='.$_GET['lid'].'">'.$lp['title'].'</a> '.lang('plugin/aljes','aljes_28').' <a href="plugin.php?id=aljes&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljes','aljes_29').'</a>');
		}
		//showmsg(lang('plugin/aljes','aljes_10'));
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']){
			echo "<script>parent.tips('".str_replace('\\','',lang('plugin/aljes','aljes_10'))."',function(){parent.location.href='plugin.php?id=aljes&act=view&lid=".$_GET['lid']."';});</script>";
		}else{
			showmsg(str_replace('\\','',lang('plugin/aljes','aljes_10')), 2, $_GET['lid']);
		}
	}
}else if($_GET['act'] == 'reply'){
	if(submitcheck('formhash')){
		if (empty($_G['uid'])) {
			showerror(lang('plugin/aljes','aljes_1'));
		}
		if (empty($_GET['message'])) {
			showerror(lang('plugin/aljes','aljes_9'));
		}
		$insertarray=array(
			'content'=>$_GET['message'],	
			'uid'=>$_G['uid'],	
			'username'=>$_G['username'],	
			'lid'=>$_GET['lid'],
			'dateline'=>TIMESTAMP,
			'upid'=>$_GET['upid'],
		);
		C::t('#aljes#aljes_comment')->insert($insertarray);
		if($config['is_ping']){
			$lp=C::t('#aljes#aljes_comment')->fetch($_GET['upid']);
			notification_add($lp['uid'], 'system',lang('plugin/aljes','aljes_30').$config['daohang'].lang('plugin/aljes','aljes_31').' <a href="plugin.php?id=aljes&act=view&lid='.$_GET['lid'].'" target="_blank">'.lang('plugin/aljes','aljes_29').'</a>');
		}
		showmsg(lang('plugin/aljes','aljes_10'));
	}
}else if($_GET['act'] == 'commentdel'){
	if($_GET['formhash']==formhash()){
		if (empty($_G['uid'])) {
			showerror(lang('plugin/aljes','aljes_1'));
		}
		$upid=DB::fetch_all(" select * from %t where upid=%d",array('aljes_comment',$_GET['cid']));
		if($upid){
			foreach($upid as $id){
				C::t('#aljes#aljes_comment')->delete($id['id']);
			}
		}
		C::t('#aljes#aljes_comment')->delete($_GET['cid']);
		showmessage(lang('plugin/aljes','aljes_7'),'plugin.php?id=aljes&act=view&lid='.$_GET['lid']);
	}
}else if ($_GET['act'] == 'getregion') {
    if ($_GET['rid']) {
        $rs = C::t('#aljes#aljes_region')->fetch_all_by_upid($_GET['rid']);
    }

    include template('aljes:getregion');
}else if($_GET['act']=='getregion1'){
	if($_GET['upid']){
		$rlist=C::t('#aljes#aljes_region')->fetch_all_by_upid($_GET['upid']);
	}
	include template('aljes:getregion1');
} else if ($_GET['act'] == 'member') {
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    
    $start = ($currpage - 1) * $perpage;
	if($_G['groupid']!=1){
		$conndtion = array(
			'uid' => $_G['uid'],
		);
	}
    $num = C::t('#aljes#aljes')->count_by_status($conndtion);
    $lplist = C::t('#aljes#aljes')->fetch_all_by_addtime($start, $perpage, $conndtion);
	//debug($lplist);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljes&act=member', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljes_seo['member']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['member']);
	}
    include template('aljes:member');
} else if ($_GET['act'] == 'adminlp') {
    if (file_exists("source/plugin/aljes/template/com/admin.php")) {
        include 'source/plugin/aljes/template/com/admin.php';
    }
} else if ($_GET['act'] == 'adminuser') {
    if (file_exists("source/plugin/aljes/template/com/user.php")) {
        include 'source/plugin/aljes/template/com/user.php';
    }
} else if ($_GET['act'] == 'adminreflash') {
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = 10;
    $num = C::t('#aljes#aljes_reflashlog')->count();
    //$num = DB::result_first(" select count(*) from ".DB::table('aljes_reflashlog')." where title!=null ");
    $start = ($currpage - 1) * $perpage;

    $logs = C::t('#aljes#aljes_reflashlog')->range($start, $perpage, 'desc');
    //$logs = DB::fetch_all(" select * from ".DB::table('aljes_reflashlog')." where title!=null order by id desc limit $start,$perpage");
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljes&act=adminreflash', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljes_seo['adminreflash']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['adminreflash']);
	}
    include template('aljes:adminreflash');
} else if ($_GET['act'] == 'admintop') {
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    $num = C::t('#aljes#aljes_toplog')->count();
    $start = ($currpage - 1) * $perpage;

    $logs = C::t('#aljes#aljes_toplog')->range($start, $perpage, 'desc');
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljes&act=admintop', 0, 11, false, false);
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljes_seo['admintop']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['admintop']);
	}
    include template('aljes:admintop');
}else if($_GET['act'] == 'all'){
	if (file_exists("source/plugin/aljes/template/com/qita.php")) {
        include 'source/plugin/aljes/template/com/qita.php';
    }
} else if($_GET['act'] == 'upload') {
	
	$_G['uid'] = intval($_GET['uid']);
	if(empty($_G['uid'])){
		$errorcode = $_G['uid'];
		echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\", \"errorcode\":".$errorcode."}";
		exit;
	}
	if($_GET['hash'] != md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])){
		$errorcode = 2;
		echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\", \"errorcode\":".$errorcode."}";
		exit;
	}
	if ($_FILES['Filedata']['tmp_name']) {
		$picname = $_FILES['Filedata']['name'];
		$picsize = $_FILES['Filedata']['size'];
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$img_dir = 'source/plugin/aljes/images/logo/';
			if (!is_dir($img_dir)) {
				mkdir($img_dir);
			}
			$pic = $img_dir . $pics;
			if (@copy($_FILES['Filedata']['tmp_name'], $pic) || @move_uploaded_file($_FILES['Filedata']['tmp_name'], $pic)) {
				$imageinfo = getimagesize($pic);
				if($settings['iswatermark']['value']){
					$image->Watermark(DISCUZ_ROOT.'./'.$pic,'', 'forum');
				}
				$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
				$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;
				
				$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
				$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
				$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
				$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

				img2thumb($pic, $pic . '.140x100.jpg', $w140, $h100);
				img2thumb($pic, $pic . '.64x64.jpg', $w64, $h64);
				img2thumb($pic, $pic . '.640x480.jpg', $w640, $h480);
				@unlink($_FILES['Filedata']['tmp_name']);
			}
		}
	}
	$aid = C::t('#aljes#aljes_attachment') -> insert(array('pic' => $pic),true);
	echo "{\"picid\":\"".$aid."\", \"url\":\"".$pic."\"}";
} else if($_GET['act'] == 'deleteattach'){
	$aid = htmlspecialchars(intval($_GET['aid']));
	if($aid){
		$attach = C::t('#aljes#aljes_attachment') -> fetch($aid);
		C::t('#aljes#aljes_attachment') -> delete($aid);
		@unlink($attach['pic']);
		@unlink($attach['pic'].'.140x100.jpg');
		@unlink($attach['pic'].'.64x64.jpg');
		@unlink($attach['pic'].'.640x480.jpg');
		
		if(empty($_GET['m'])){
			include template('common/header_ajax');
			echo '<script type="text/javascript">$("td_'.$_GET['aid'].'").remove()</script>';
			include template('common/footer_ajax');
		}
	}
}  else if($_GET['act'] == 'mobile_deleteattach'){
	$lid = intval($_GET['lid']);
	$dataindex = intval($_GET['dataindex']);
	if($lid && $dataindex){
		$info = C::t('#aljes#aljes') -> fetch($lid);
		$pic = 'pic'.$dataindex;
		@unlink($info[$pic]);
		@unlink($info[$pic].'.140x100.jpg');
		@unlink($info[$pic].'.64x64.jpg');
		@unlink($info[$pic].'.640x480.jpg');
		DB::query('update %t set '.$pic."='' where id=%d",array('aljes',$lid));
		$aid=DB::result_first('select aid from %t where pic =%s',array('aljes_attachment',$info[$pic]));
		C::t('#aljes#aljes_attachment') -> delete($aid);
		echo 1;
	}else{
		echo 0;
	}
	exit;
}else if($_GET['act'] == 'mupload'){
	
	$fn = (isset($_SERVER['HTTP_X_FILENAME']) ? $_SERVER['HTTP_X_FILENAME'] : false);
	if ($fn) {
		$rand = rand(100, 999);
		$pics = date("YmdHis") . $rand . '.jpg';
		$img_dir = 'source/plugin/aljes/images/logo/';
		if (!is_dir($img_dir)) {
			mkdir($img_dir);
		}
		$pic = $img_dir . $pics;
		file_put_contents($pic,file_get_contents('php://input'));
		if (file_exists($pic)) {
			$imageinfo = getimagesize($pic);
			if($settings['iswatermark']['value']){
				$image->Watermark(DISCUZ_ROOT.'./'.$pic,'', 'forum');
			}
			$w64 = $imageinfo[0] < 64 ? $imageinfo[0] : 64;
			$h64 = $imageinfo[1] < 64 ? $imageinfo[1] : 64;
			
			$w640 = $imageinfo[0] < 640 ? $imageinfo[0] : 640;
			$h480 = $imageinfo[1] < 480 ? $imageinfo[1] : 480;
			$w140 = $imageinfo[0] < 140 ? $imageinfo[0] : 140;
			$h100 = $imageinfo[1] < 100 ? $imageinfo[1] : 100;

			img2thumb($pic, $pic . '.140x100.jpg', $w140, $h100);
			img2thumb($pic, $pic . '.64x64.jpg', $w64, $h64);
			img2thumb($pic, $pic . '.640x480.jpg', $w640, $h480);
		}
		$aid = C::t('#aljes#aljes_attachment') -> insert(array('pic' => $pic),true);
		echo $aid;
		exit();
	}
} else {
	$types = C::t('#aljes#aljes_position') -> range();
	$gtypes_tmp = DB::fetch_all('select * from %t where upid = 0  order by displayorder asc',array('aljes_position'));
	
	foreach($gtypes_tmp as $gk => $gtype){
		$gtypes[$gtype['id']] = $gtype;
		$ids_tmp = DB::fetch_all('select id from %t where upid = %d order by displayorder asc',array('aljes_position',$gtype['id']));
		foreach($ids_tmp as $id){
			$tmp_subtype = C::t('#aljes#aljes_position') -> fetch_all_by_upid($id['id']);
			$sub3ids[$id['id']] = $tmp_subtype;
			$ids[] = $id['id'];
		}
		$gtypes[$gtype['id']]['subid'] = $ids;
		unset($ids);
		
	}
	//debug($gtypes[$_GET['zufangtype']]);
    $todayviews = C::t('#aljes#aljes_log')->fetch_all_by_day();
    $regions = C::t('#aljes#aljes_region')->range();
    $rs = C::t('#aljes#aljes_region')->fetch_all_by_upid(0);
    $rrs = C::t('#aljes#aljes_region')->fetch_all_by_upid($_GET['rid']);
	$subrrs = C::t('#aljes#aljes_region')->fetch_all_by_upid($_GET['subrid']);
    $currpage = $_GET['page'] ? $_GET['page'] : 1;
    $perpage = $config['page'];
    if($_GET['mobile']=='1'||$_GET['mobile']=='2'){
		if($_G['charset']=='gbk'){ $_GET['search']=diconv($_GET['search'],'utf-8','gbk');}
	}
    $start = ($currpage - 1) * $perpage;
    $conndtion = array(
        'search' => $_GET['search'],
        'rid' => $_GET['region']?$_GET['region']:$_GET['rid'],
        'subrid' => $_GET['region1']?$_GET['region1']:$_GET['subrid'],
        'subsubrid' => $_GET['region2']?$_GET['region2']:$_GET['subsubrid'],
        'zufangtype' => $_GET['zufangtype'],
        'subtype' => $_GET['subtype'],
        'subsubtype' => $_GET['subsubtype'],
        'pay1' => $_GET['pay1'],
        'pay2' => $_GET['pay2'],
        'wanted' => $_GET['wanted'],
        'new' => $_GET['new'],
        'solve' => $_GET['solve'],
        'pic' => $_GET['pic'],
        'sort' => $_GET['sort'],
    );
	if($config['is_solve'] && file_exists("source/plugin/aljes/template/com/solve.php")){
		$conndtion['is_solve']=1;
	}
	$num = C::t('#aljes#aljes')->count_by_status($conndtion);
	
    $lplist = C::t('#aljes#aljes')->fetch_all_by_addtime($start, $perpage, $conndtion);
	foreach($lplist as $k=>$v){
		if(TIMESTAMP>$v['topetime']&&$v['topetime']){
			DB::update('aljes',array('topstime'=>'','topetime'=>''),'id='.$v[id]);
		}
		$lplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
    $lplist = dhtmlspecialchars($lplist);
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljes&search='.$_GET['search'].'&rid='.$_GET['rid'].'&subrid='.$_GET['subrid'].'&pay1='.$_GET['pay1'].'&pay2='.$_GET['pay2'].'&zufangtype='.$_GET['zufangtype'].'&new='.$_GET['new'].'&view='.$_GET['view'].'&solve='.$_GET['solve'].'&subtype='.$_GET['subtype'].'&subsubtype='.$_GET['subsubtype'].'&pic='.$_GET['pic'], 0, 11, false, false);
	$tuijian = DB::fetch_all("SELECT * FROM ".DB::table('aljes')." where state=0 and tuijian=1 ORDER BY id desc limit 0,9");
	foreach($tuijian as $k=>$v){
		$tuijian[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
    $toplist = C::t('#aljes#aljes_toplog')->fetch_all_by_dateline();
	foreach($toplist as $k=>$v){
		$toplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	
    $navtitle = $config['title'];
    $metakeywords = $config['keywords'];
    $metadescription = $config['description'];
	if($aljes_seo['list']['seotitle']){
		if($_GET['rid']){
			$title=$regions[$_GET['rid']]['subject'];
			$title1 = $title;
		}
		if($_GET['subrid']){
			$title=$regions[$_GET['subrid']]['subject'];
			$title2=$title; 
			
		}
		if($_GET['subsubrid']){
			$title=$regions[$_GET['subsubrid']]['subject'];
			$title3=$title;
		}
		
		if($_GET['zufangtype']){
			$cat=$types[$_GET['zufangtype']]['subject'];
		}
		if($_GET['subtype']){
			$cat1=$types[$_GET['subtype']]['subject'];
		}
		if($_GET['subsubtype']){
			$cat2=$types[$_GET['subsubtype']]['subject'];
		}
		if($_GET['pay1'] || $_GET['pay2']){
			$zujin_1=$_GET['pay1']?$_GET['pay1'].($_GET['pay2']?lang('plugin/aljes','yuan_1'):lang('plugin/aljes','yuan_2')):'';
			$zujin_2=$_GET['pay2']?$_GET['pay2'].(!$_GET[pay1]?lang('plugin/aljes','yuan_3'):lang('plugin/aljes','yuan')):'';
			$zujin=$zujin_1.$zujin_2;
		}
		$seodata = array('bbname' => $_G['setting']['bbname'],'cat'=>$cat,'cat1'=>$cat1,'cat2'=>$cat2,'new'=>$new_types[$_GET['new']],'pay'=>$zujin,'region'=>$title1,'region2'=>$title2,'region3'=>$title3);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['list']);
	}
	if($config['template_all'] == '2'){
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
			include template('aljes:58/aljes_index');
		} else {
			include template('diy:aljes_index', null, 'source/plugin/aljes/template/58');
		}
	}else{
		if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
			include template('aljes:aljes_index');
		} else {
			include template('diy:aljes_index', null, 'source/plugin/aljes/template/');
		}
	}
}

function showmsg($msg, $close, $id) {
    if ($close == 1) {
        $str = "parent.hideWindow('$close');";
    } else if ($close == 2) {
        $str = "parent.location.href='plugin.php?id=aljes&act=view&lid=" . $id . "'";
    } else {
        $str = "parent.location=parent.location;";
    }
    include template('aljes:showmsg');
    exit;
}

function showerror($msg) {
    include template('aljes:showerror');
    exit;
}

function img2thumb($src_img, $dst_img, $width = 75, $height = 75, $cut = 0, $proportion = 0) {
    if (!is_file($src_img)) {
        return false;
    }
    $ot = fileext($dst_img);
    $otfunc = 'image' . ($ot == 'jpg' ? 'jpeg' : $ot);
    $srcinfo = getimagesize($src_img);
    $src_w = $srcinfo[0];
    $src_h = $srcinfo[1];
    $type = strtolower(substr(image_type_to_extension($srcinfo[2]), 1));
    $createfun = 'imagecreatefrom' . ($type == 'jpg' ? 'jpeg' : $type);

    $dst_h = $height;
    $dst_w = $width;
    $x = $y = 0;

    if (($width > $src_w && $height > $src_h) || ($height > $src_h && $width == 0) || ($width > $src_w && $height == 0)) {
        $proportion = 1;
    }
    if ($width > $src_w) {
        $dst_w = $width = $src_w;
    }
    if ($height > $src_h) {
        $dst_h = $height = $src_h;
    }

    if (!$width && !$height && !$proportion) {
        return false;
    }
    if (!$proportion) {
        if ($cut == 0) {
            if ($dst_w && $dst_h) {
                if ($dst_w / $src_w > $dst_h / $src_h) {
                    $dst_w = $src_w * ($dst_h / $src_h);
                    $x = 0 - ($dst_w - $width) / 2;
                } else {
                    $dst_h = $src_h * ($dst_w / $src_w);
                    $y = 0 - ($dst_h - $height) / 2;
                }
            } else if ($dst_w xor $dst_h) {
                if ($dst_w && !$dst_h) {
                    $propor = $dst_w / $src_w;
                    $height = $dst_h = $src_h * $propor;
                } else if (!$dst_w && $dst_h) {
                    $propor = $dst_h / $src_h;
                    $width = $dst_w = $src_w * $propor;
                }
            }
        } else {
            if (!$dst_h) {
                $height = $dst_h = $dst_w;
            }
            if (!$dst_w) {
                $width = $dst_w = $dst_h;
            }
            $propor = min(max($dst_w / $src_w, $dst_h / $src_h), 1);
            $dst_w = (int) round($src_w * $propor);
            $dst_h = (int) round($src_h * $propor);
            $x = ($width - $dst_w) / 2;
            $y = ($height - $dst_h) / 2;
        }
    } else {
        $proportion = min($proportion, 1);
        $height = $dst_h = $src_h * $proportion;
        $width = $dst_w = $src_w * $proportion;
    }

    $src = $createfun($src_img);
    $dst = imagecreatetruecolor($width ? $width : $dst_w, $height ? $height : $dst_h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefill($dst, 0, 0, $white);

    if (function_exists('imagecopyresampled')) {
        imagecopyresampled($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    } else {
        imagecopyresized($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    $otfunc($dst, $dst_img);
    imagedestroy($dst);
    imagedestroy($src);
    return true;
}
function hidtel($phone)
{
    $IsWhat = preg_match('/([0-9][0-9]{2,3}[\-]?[1-9][0-9]{6,7}[\-]?[0-9]?)/i',$phone); //�̶��绰
	
    if($IsWhat == 1)
    {
        return preg_replace('/([0-9][0-9]{2,3}[\-]?[1-9])[0-9]{3,4}([0-9]{3}[\-]?[0-9]?)/i','$1****$2',$phone);
    }
    else
    {
        return  preg_replace('/([0-9][0-9]{1}[0-9])[0-9]{4}([0-9]{4})/i','$1****$2',$phone);
    }
}
function stripBBCode($text_to_search) {
	 $pattern = '|[[\/\!]*?[^\[\]]*?]|si';
	 $replace = '';
	 return preg_replace($pattern, $replace, $text_to_search);
}
?>
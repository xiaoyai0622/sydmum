<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$file = 'aljes_qrcode.jpg';	 QRcode::png($_G['siteurl'].'plugin.php?id=aljes', 'source/plugin/aljes/images/qrcode/'.$file, QR_MODE_STRUCTURE, 8);
?>
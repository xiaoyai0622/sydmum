<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($config['es_fid']){
	if($config['isrewrite']){
		$re_url=str_replace ("{id}",$insertid, $config ['re_view']);
	}else{
		$re_url='plugin.php?id=aljes&act=view&lid='.$insertid;
	}
	$str.='[size=4][url='.$re_url.']'.$_GET['title'].'[/url] [url='.$re_url.'][color=red]'.lang('plugin/aljes','thread_10').'[/color][/url]<br/>';
	$str.=str_replace('{tel}',$_GET['contact'],str_replace('{wanted}',$wanted_types[$_GET['wanted']],str_replace('{zf_type}',$pos_all[$_GET['zufangtype']]['subject'],str_replace('{zujin}',$_GET['zujin']>0?intval($_GET['zujin']):lang('plugin/aljes','aljes_23'),lang('plugin/aljes','thread_2')))));		
	if($_GET['new']){
		$str.=str_replace('{new}',$new_types[$_GET['new']],lang('plugin/aljes','thread_3'));
	}
	if($_GET['qq']){
		$str.=str_replace('{qq}',$_GET['qq'],lang('plugin/aljes','thread_4'));
	}
	if($_GET['lxr']){
		$str.=str_replace('{lxr}',$_GET['lxr'],lang('plugin/aljes','thread_5'));
	}
	if($_GET['region1']||$_GET['region']||$_GET['region2']){
		if($_GET['region2']&&$_GET['region1']&&$_GET['region']){
			$str.=str_replace('{region2}',$regions[$_GET['region2']]['subject'],str_replace('{region1}',$regions[$_GET['region1']]['subject'],str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljes','thread_6'))));
		}else if($_GET['region1']&&$_GET['region']&&!$_GET['region2']){
			$str.=str_replace('{region1}',$regions[$_GET['region1']]['subject'],str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljes','thread_7')));
		}else if($_GET['region']&&!$_GET['region2']&&!$_GET['region1']){
			$str.=str_replace('{region}',$regions[$_GET['region']]['subject'],lang('plugin/aljes','thread_8'));
		}
	}
	$str.=str_replace('{shengming}',$shengming,lang('plugin/aljes','thread_9'));
	if($_GET['content']){
		$str.=str_replace('{content}',discuzcode($_GET['content']),'{content}[/size]');	
	}
	$cont=str_replace('&amp;','&',html2bbcode($str));
	$tid = generatethread('['.$config['daohang'].']'.$_GET['title'], $cont, $_G['clientip'], $_G['uid'], '', $config['es_fid'],$config['threadtypes']);
	C::t('#aljes#aljes')->update($insertid,array('tid'=>$tid));
}
?>
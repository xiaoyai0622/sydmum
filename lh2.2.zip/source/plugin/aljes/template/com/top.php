<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (submitcheck('formhash')) {
	if(empty($_GET['lid'])){
		showmessage(lang('plugin/aljes','aljes_8'));
	}
	if($_GET['days']<0){
		 
		if($_G['mobile']){
			echo "<script>parent.tips('".lang('plugin/aljes','top_3')."','');</script>";
			exit;
		}else{
			showerror(lang('plugin/aljes','top_3'));
		}
	}
	$lp=C::t('#aljes#aljes')->fetch($_GET['lid']);
	$insertid=C::t('#aljes#aljes_toplog')->insert(array(
		'lid' => $_GET['lid'],
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'dateline' => TIMESTAMP,
		'endtime' => TIMESTAMP+$_GET['days']*86400,
		'pay' => $_GET['days']*$config['toppay'],
		'extcredit' => $config['topextcredit'],
		'title' => $lp['title'],
		'name' => $lp['username'],
	),true);
	if (getuserprofile('extcredits' . $config['topextcredit']) < ($_GET['days']*$config['toppay'])) {
		if($_G['mobile']){
			echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljes','top_1')."','');</script>";
			exit;
		}else{
			showerror($_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljes','top_1'));
		}
	}
	updatemembercount($_G['uid'], array($config['topextcredit'] => '-' .$_GET['days']*$config['toppay']));
	if($lp['topetime']&&TIMESTAMP<$lp['topetime']){
		DB::update('aljes_toplog',array('endtime'=>$lp['topetime']+$_GET['days']*86400),'id='.$insertid);
		DB::update('aljes',array('topetime'=>$lp['topetime']+$_GET['days']*86400),'id='.$_GET[lid]);
	}else{
		DB::update('aljes',array('topstime'=>TIMESTAMP,'topetime'=>TIMESTAMP+$_GET['days']*86400),'id='.$_GET[lid]);
	}
	C::t('#aljes#aljes_user')->update_top_by_uid($_G['uid']);
	if($_G['mobile']){
		echo "<script>parent.tips('".lang('plugin/aljes','top_2')."',function(){parent.location.href='plugin.php?id=aljes&act=member"."';});</script>";
		exit;
	}else{
		showmsg(lang('plugin/aljes','top_2'), 'plugin.php?id=aljes&act=member');
	}
}else{
	if (getuserprofile('extcredits' . $config['topextcredit']) < $config['toppay']) {
		showmessage($_G['setting']['extcredits'][$config['topextcredit']]['title'] . lang('plugin/aljes','top_1'));
	}
	$lp=C::t('#aljes#aljes')->fetch($_GET['lid']);
	
	if($_G['mobile']){
		$url='plugin.php?id=aljes&act=top&lid='.$_GET['lid'];
		include template('aljes:state');
	}else{
		include template('aljes:addtop');
	}
}
?>
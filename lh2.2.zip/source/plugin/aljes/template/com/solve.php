<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (empty($_GET['lid'])) {
	showmessage(lang('plugin/aljes','aljes_10'));
}

if($_GET['formhash'] == formhash()){
	$user=C::t('#aljes#aljes')->fetch($_GET['lid']);
	if($_G['mobile']){
		if (submitcheck('submit')) {
			if($_GET['solve']=='re'){
				C::t('#aljes#aljes')->update($_GET['lid'], array('solve'=>'0'));
				showmessage(lang('plugin/aljes','The_re_release_of_success'),'plugin.php?id=aljes&act=member');
			}else{
				C::t('#aljes#aljes')->update($_GET['lid'], array('solve'=>'1'));
				showmessage(lang('plugin/aljes','To_get_success!'),'plugin.php?id=aljes&act=member');
			}
		}else{
			if($_GET['re']=='1'){
				$url='plugin.php?id=aljes&act=solve&lid='.$_GET['lid'].'&solve=re';
			}else{
				$url='plugin.php?id=aljes&act=solve&lid='.$_GET['lid'];
			}
			include template('aljes:state');
		}
	}else{
		if($_GET['solve']=='re'){
			C::t('#aljes#aljes')->update($_GET['lid'], array('solve'=>'0'));
			showmessage(lang('plugin/aljes','The_re_release_of_success'),'plugin.php?id=aljes&act=member');
		}else{
			C::t('#aljes#aljes')->update($_GET['lid'], array('solve'=>'1'));
			showmessage(lang('plugin/aljes','To_get_success!'),'plugin.php?id=aljes&act=member');
		}
	}
}
?>
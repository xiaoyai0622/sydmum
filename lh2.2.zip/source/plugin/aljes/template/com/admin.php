<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$currpage = $_GET['page'] ? $_GET['page'] : 1;
$perpage = $config['page'];
$conndtion = array(
    'uid' => $_GET['uid'],
    'search' => $_GET['search'],
);
$num = C::t('#aljes#aljes')->count_by_status($conndtion);
$start = ($currpage - 1) * $perpage;

$lplist = C::t('#aljes#aljes')->fetch_all_by_addtime($start, $perpage, $conndtion);
$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljes&act=adminlp&search='.$_GET['search'], 0, 11, false, false);
$users = C::t('#aljes#aljes_user')->range();
$navtitle = $config['title'];
$metakeywords = $config['keywords'];
$metadescription = $config['description'];
if($aljes_seo['adminlp']['seotitle']){
	$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['adminlp']);
}
include template('aljes:adminlp');
?>
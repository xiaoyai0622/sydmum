<?php
if (submitcheck('formhash')) {
	
	if ($_FILES['pic']['tmp_name']) {
		$picname = $_FILES['pic']['name'];
		$picsize = $_FILES['pic']['size'];
		if ($picsize/1024>$config['img_size']) {
			showerror(lang('plugin/aljes','aljes_40').$config['img_size'].'K');
		}
		if ($picname != "") {
			$type = strstr($picname, '.');
			if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
				showerror(lang('plugin/aljes','aljes_7'));
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$img_dir = 'source/plugin/aljes/images/logo/';
			if (!is_dir($img_dir)) {
				mkdir($img_dir);
			}
			$$pic = $img_dir . $pics;
			if (@copy($_FILES['pic']['tmp_name'], $$pic) || @move_uploaded_file($_FILES['pic']['tmp_name'], $$pic)) {
				$imageinfo = getimagesize($$pic);
				@unlink($_FILES['pic']['tmp_name']);
			}
		}
	}
}
if($_GET['form']=='shenfen'){
	if (submitcheck('formhash')) {
		$rz2=C::t('#aljes#aljes_attestation')->fetch_uid_type_sign($_G['uid'],'2');
		if($rz2){
			C::t('#aljes#aljes_attestation')->delete($rz2['id']);
		}
		$insertarray = array(
			'type' => '1',
			'username' => $_G['username'],
			'uid' => $_G['uid'],
			'timestamp' => TIMESTAMP,
			'num' => $_GET['str_idcard'],
		);
		if ($$pic) {
			$insertarray['pic'] = $$pic;
		}
		if($config['r_ext']&&$r_pay['0']){
			if (getuserprofile('extcredits' . $config['r_ext']) < $r_pay['0']) {
				showerror($_G['setting']['extcredits'][$config['r_ext']]['title'] . lang('plugin/aljes','top_1'));
			}
			updatemembercount($_G['uid'], array($config['r_ext'] => '-' . $r_pay['0']));
		}
		if(C::t('#aljes#aljes_attestation')->fetch_uid_type($_G['uid'],'1')){
			$insertarray['sign'] = 0;
			DB::update('aljes_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'1'));
		}else{
			if(!$$pic){
				showerror(lang('plugin/aljes','aljes_42'));
			}
			C::t('#aljes#aljes_attestation')->insert($insertarray);
		}
		showmsg(lang('plugin/aljes','aljes_43'));
	}
}else if($_GET['form']=='gongsi'){
	if (submitcheck('formhash')) {
		$rz1=C::t('#aljes#aljes_attestation')->fetch_uid_type_sign($_G['uid'],'1');
		if($rz1){
			C::t('#aljes#aljes_attestation')->delete($rz1['id']);
		}
		$insertarray = array(
			'type' => '2',
			'username' => $_G['username'],
			'uid' => $_G['uid'],
			'timestamp' => TIMESTAMP,
			'num' => $_GET['num'],
			'gongsiname' => $_GET['gongsiname'],
		);
		if ($$pic) {
			$insertarray['pic'] = $$pic;
		}
		if($config['r_ext']&&$r_pay['2']){
			if (getuserprofile('extcredits' . $config['r_ext']) < $r_pay['2']) {
				showerror($_G['setting']['extcredits'][$config['r_ext']]['title'] . lang('plugin/aljes','top_1'));
			}
			updatemembercount($_G['uid'], array($config['r_ext'] => '-' . $r_pay['2']));
		}
		if(C::t('#aljes#aljes_attestation')->fetch_uid_type($_G['uid'],'2')){
			$insertarray['sign'] = 0;
			DB::update('aljes_attestation', $insertarray, array("uid"=>$_G['uid'],'type'=>'2'));
		}else{
			if(!$$pic){
				showerror(lang('plugin/aljes','aljes_42'));
			}
			C::t('#aljes#aljes_attestation')->insert($insertarray);
		}
		showmsg(lang('plugin/aljes','aljes_43'));
	}
}else{
	$rz1=C::t('#aljes#aljes_attestation')->fetch_uid_type_sign($_G['uid'],'1');
	$rz2=C::t('#aljes#aljes_attestation')->fetch_uid_type_sign($_G['uid'],'2');
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($aljes_seo['admintop']['seotitle']){
		$seodata = array('bbname' => $_G['setting']['bbname'],'username'=>$_G['username']);
		list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $aljes_seo['admintop']);
	}
	include template('aljes:attestation');
}
?>
<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `subtype` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `subsubtype` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `region3` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `solve` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljes_region')." ADD `level` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljes_region')." ADD `havechild` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE ".DB::table('aljes')." ADD `state` tinyint(3) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `clientip` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE ".DB::table('aljes')." ADD `phone` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljes` ADD `qrcode` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljes_toplog` CHANGE `id` `id` INT( 10 ) NOT NULL AUTO_INCREMENT " ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljes` ADD `topstime` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljes` ADD `topetime` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljes` ADD `tid` int NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljes_reflashlog` ADD `name` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljes_reflashlog` ADD `title` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljes_toplog` ADD `title` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljes_toplog` ADD `name` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');
$sql ="ALTER TABLE `pre_aljes_toplog` ADD `endtime` int NOT NULL" ;
DB::query($sql,'SILENT');
//finish to put your own code
$sql ="ALTER TABLE `pre_aljes` ADD `qq` bigint NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljes` ADD `new` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljes` ADD `lxr` varchar(255) NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljes` ADD `tuijian` int NOT NULL" ;
DB::query($sql,'SILENT');

$sql ="ALTER TABLE `pre_aljes` ADD `displayorder` int NOT NULL" ;
DB::query($sql,'SILENT');


$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljes_comment` (
  `id` int(11) NOT NULL auto_increment,
  `upid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `lid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `upid` (`upid`),
  KEY `dateline` (`dateline`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljes_position` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `upid` mediumint(9) unsigned NOT NULL,
  `subid` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `displayorder` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljes_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljes_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`key`)
);
CREATE TABLE IF NOT EXISTS `pre_aljes_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dateline` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljes_attachment` (
  `aid` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `pid` int(10) NOT NULL,
  PRIMARY KEY (`aid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljes_attestation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `gongsiname` varchar(255) NOT NULL,
  `num` bigint(20) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `sign` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
)
EOF;
runquery($sql);
$sql ="ALTER TABLE ".DB::table('aljes_appointment')." ADD `buid` int NOT NULL" ;
DB::query($sql,'SILENT');
if(file_exists( DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')&&file_exists( DISCUZ_ROOT . './source/plugin/aljes/template/touch/index.htm')){
	$pluginid = 'aljes';
	$Hooks = array(
		'forumdisplay_topBar',
	);
	$data = array();
	foreach ($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid . '_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::updateAPIHook($data);
}
$finish = TRUE;
?>
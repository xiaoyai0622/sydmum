<?php

/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

echo "<script language='javascript'>";
echo "window.location.href='http://addon.discuz.com/?@3932.developer'";
echo "</script>";
exit;
?>
<?php
/*
 * ���ߣ�����
 * ��ϵQQ:578933760
 *
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljes_attachment extends discuz_table{
	public function __construct() {

			$this->_table = 'aljes_attachment';
			$this->_pk    = 'aid';

			parent::__construct();
	}
}




?>
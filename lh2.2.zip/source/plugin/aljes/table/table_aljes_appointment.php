<?php
/*
 * 作�?：亮�?
 * 联系QQ:578933760
 *
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljes_appointment extends discuz_table
{
	public function __construct() {

		$this->_table = 'aljes_appointment';
		$this->_pk    = 'id';

		parent::__construct();
	}
	public function update_state_by_id($id) {
        DB::query('update %t set state=1 where id=%d', array($this->_table, $id));
    }
}

?>
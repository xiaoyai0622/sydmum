<?PHP exit('Access Denied');?>
<!--{subtemplate common/header}-->
<style id="diy_style" type="text/css"></style>
<!--[diy=comiis01]--><div id="comiis01" class="area"></div><!--[/diy]-->
<!--[diy=comiis_xun01]--><div id="comiis_xun01" class="area"></div><!--[/diy]-->
<div class="clearfix comiis_wrap960">
  <div class="comiis_wrap676">
    <div class="comiis_wrap277">
      <div class="comiis_imgs">
		<!--[diy=comiis_xun02]--><div id="comiis_xun02" class="area"></div><!--[/diy]-->
      </div>
      <h2 class="comiis_titone">��̳����</h2>
      <div class="comiis_wrap261">
		<!--[diy=comiis_xun03]--><div id="comiis_xun03" class="area"></div><!--[/diy]-->
      </div>
    </div>
    <div class="comiis_wrap399">
		<!--[diy=comiis_xun04]--><div id="comiis_xun04" class="area"></div><!--[/diy]-->
    </div>
  </div>
  <div class="comiis_wrap270">
    <div class="comiis_wrap266">
      <div class="comiis_tittwo">
        <h2>ͼ���ȵ�</h2>
      </div>
      <div class="comiis_wrap248">
		<!--[diy=comiis_xun05]--><div id="comiis_xun05" class="area"></div><!--[/diy]-->
      </div>
    </div>
    <div class="comiis_wrapad">
		<!--[diy=comiis_xun06]--><div id="comiis_xun06" class="area"></div><!--[/diy]-->
    </div>
  </div>
</div>
<div class="clearfix comiis_wrap960">
  <div class="comiis_wrap676 comiis_height504">
    <div class="comiis_tittwo">
      <h2 class="comiis_bgone">������԰</h2>
      <span><a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a></span></div>
    <div class="clearfix">
	  <div class="comiis_wrap240">
	    <!--[diy=comiis_xun07]--><div id="comiis_xun07" class="area"></div><!--[/diy]-->
	  </div>
      <div class="comiis_wrap404">
        <!--[diy=comiis_xun08]--><div id="comiis_xun08" class="area"></div><!--[/diy]-->
        <div class="comiis_wrapimgs">
          <div class="comiis_fontimgs">
			<!--[diy=comiis_xun09]--><div id="comiis_xun09" class="area"></div><!--[/diy]-->
          </div>
          <div class="kmul">
			<!--[diy=comiis_xun11]--><div id="comiis_xun11" class="area"></div><!--[/diy]-->
          </div>
        </div>
        <div class="comiis_wrapimgs">
          <div class="comiis_fontimgs">
			<!--[diy=comiis_xun10]--><div id="comiis_xun10" class="area"></div><!--[/diy]-->
          </div>
          <div class="kmul">
			<!--[diy=comiis_xun12]--><div id="comiis_xun12" class="area"></div><!--[/diy]-->
          </div>
        </div>
      </div>
    </div>
    <!--[diy=comiis_xun13]--><div id="comiis_xun13" class="area"></div><!--[/diy]-->
  </div>
  <div class="comiis_wrap270">
    <div class="comiis_wrap266 comiis_height349">
      <div class="comiis_tittwo">
        <h2 class="comiis_bgtwo">�����Ż�</h2>
      </div>
      <div class="comiis_ulfour">
		<!--[diy=comiis_xun14]--><div id="comiis_xun14" class="area"></div><!--[/diy]-->
      </div>
    </div>
    <div class="comiis_wrapad">
		<!--[diy=comiis_xun15]--><div id="comiis_xun15" class="area"></div><!--[/diy]-->
    </div>
  </div>
</div>
<div class="clearfix comiis_wrap960">
  <div class="comiis_wrap676 comiis_boxone">
    <div class="comiis_tittwo">
      <h2 class="comiis_bgthree">�Ժ�����</h2>
      <span><a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a></span></div>
	  <div class="comiis_wrap238">
		<!--[diy=comiis_xun16]--><div id="comiis_xun16" class="area"></div><!--[/diy]-->
		<h3>�����Ƽ�</h3>
		<!--[diy=comiis_xun17]--><div id="comiis_xun17" class="area"></div><!--[/diy]-->
    </div>
    <div class="comiis_wrap404">
		<!--[diy=comiis_xun18]--><div id="comiis_xun18" class="area"></div><!--[/diy]-->
    </div>
  </div>
  <script type="text/javascript">
function kmtab(o){
	 for(var i=1;i<=4;i++){
		   $("menu"+i).className="";
		   $("tab"+i).className="hidden";
   }	   
   $("menu"+o).className="current";
   $("tab"+o).className="";
}
</script>
  <div class="comiis_wrap270">
    <div class="comiis_wrap266 comiis_height387">
      <div class="comiis_tittwo">
        <h2 class="comiis_bgfour">�Ժ�����</h2>
      </div>
      <ul id="comiis_ulid">
        <li id="menu1" class="current" onmouseover="kmtab(1)"><a href="#" taret=_blank>��Ƹ</a></li>
        <li id="menu2" onmouseover="kmtab(2)"><a href="#" taret=_blank>�ⷿ</a></li>
        <li id="menu3" onmouseover="kmtab(3)"><a href="#" taret=_blank>�ۿ�</a></li>
        <li id="menu4" onmouseover="kmtab(4)"><a href="#" taret=_blank>����</a></li>
      </ul>
      <div id="comiis_conid">
      <div id="tab1">
		<!--[diy=comiis_xun19]--><div id="comiis_xun19" class="area"></div><!--[/diy]-->
      </div>
        <div id="tab2" class="hidden">
			<!--[diy=comiis_xun20]--><div id="comiis_xun20" class="area"></div><!--[/diy]-->
        </div>
        <div id="tab3" class="hidden">
			<!--[diy=comiis_xun21]--><div id="comiis_xun21" class="area"></div><!--[/diy]-->
        </div>
        <div id="tab4" class="hidden">
			<!--[diy=comiis_xun22]--><div id="comiis_xun22" class="area"></div><!--[/diy]-->
        </div>
      </div>
    </div>
  </div>
</div>
<!--[diy=comiis_xun23]--><div id="comiis_xun23" class="area"></div><!--[/diy]-->
<div class="clearfix comiis_wrap960">
  <div class="comiis_wrap676 comiis_boxtwo">
    <div class="comiis_tittwo">
      <h2 class="comiis_bgfive">�����۽�</h2>
      <span><a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a></span></div>
    <div class="comiis_wrapimgfonts"> 
		<!--[diy=comiis_xun24]--><div id="comiis_xun24" class="area"></div><!--[/diy]-->
    </div>
    <div class="comiis_warptit">
		<!--[diy=comiis_xun25]--><div id="comiis_xun25" class="area"></div><!--[/diy]-->
    </div>
    <div class="comiis_home">
      <h4><strong>�ز�ר�ⱨ��</strong></h4>
      <div class="clearfix comiis_ulsix">
		<!--[diy=comiis_xun26]--><div id="comiis_xun26" class="area"></div><!--[/diy]-->
      </div>
      <div class="comiis_wrapad">
		<!--[diy=comiis_xun27]--><div id="comiis_xun27" class="area"></div><!--[/diy]-->
      </div>
    </div>
  </div>
  <div class="comiis_wrap270">
    <div class="comiis_wrap266 comiis_height336">
      <div class="comiis_tittwo">
        <h2 class="comiis_bgsix">����װ��</h2>
      </div>
      <div class="comiis_wrap249">
		<!--[diy=comiis_xun28]--><div id="comiis_xun28" class="area"></div><!--[/diy]-->
		<div class="comiis_uleight">
		<!--[diy=comiis_xun29]--><div id="comiis_xun29" class="area"></div><!--[/diy]-->
        </div>
      </div>
    </div>
  </div>
</div>
<div class="clearfix comiis_wrap960">
  <div class="comiis_wrap676 comiis_boxone comiis_boxthree">
    <div class="comiis_tittwo">
      <h2 class="comiis_bgsev">��Ҫ���</h2>
      <span><a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a></span></div>
    <div class="comiis_wrap238">
		<!--[diy=comiis_xun30]--><div id="comiis_xun30" class="area"></div><!--[/diy]-->
		<h3>�����Ƽ�</h3>
		<!--[diy=comiis_xun31]--><div id="comiis_xun31" class="area"></div><!--[/diy]-->
    </div>
    <div class="comiis_wrap404">
		<!--[diy=comiis_xun32]--><div id="comiis_xun32" class="area"></div><!--[/diy]-->
    </div>
  </div>
  <div class="comiis_wrap270">
    <div class="comiis_wrap266 comiis_height387">
      <div class="comiis_tittwo">
        <h2 class="comiis_bgeig">���н���</h2>
      </div>
      <div class="comiis_wrap249">
		<!--[diy=comiis_xun33]--><div id="comiis_xun33" class="area"></div><!--[/diy]-->
		<div class="comiis_uleight">
			<!--[diy=comiis_xun34]--><div id="comiis_xun34" class="area"></div><!--[/diy]-->
        </div>
      </div>
    </div>
  </div>
</div>
<div class="clearfix comiis_wrap960">
  <div class="comiis_wrap676 comiis_boxtwo comiis_boxfour">
    <div class="comiis_tittwo">
      <h2 class="comiis_bgnine">���г���</h2>
      <span><a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a>|<a 
      href="#" taret=_blank>�Զ�����</a></span></div>
    <div class="comiis_wrapimgfonts"> 
		<!--[diy=comiis_xun35]--><div id="comiis_xun35" class="area"></div><!--[/diy]-->
    </div>
    <div class="comiis_warptit">
		<!--[diy=comiis_xun36]--><div id="comiis_xun36" class="area"></div><!--[/diy]-->
    </div>
    <div class="comiis_tour">
      <h3>���г���</h3>
      <!--[diy=comiis_xun37]--><div id="comiis_xun37" class="area"></div><!--[/diy]-->
    </div>
  </div>
  <div class="comiis_wrap270">
    <div class="comiis_wrap266 comiis_height336 comiis_boxfive">
      <div class="comiis_tittwo">
        <h2 class="comiis_bgten">��̳��̬</h2>
      </div>
      <div class="comiis_wrap249">
		<!--[diy=comiis_xun38]--><div id="comiis_xun38" class="area"></div><!--[/diy]-->
		<div class="comiis_uleight">
			<!--[diy=comiis_xun39]--><div id="comiis_xun39" class="area"></div><!--[/diy]-->
		</div>
      </div>
    </div>
  </div>
</div>
<!--[diy=comiis_xun40]--><div id="comiis_xun40" class="area"></div><!--[/diy]-->
<div class="comiis_wrap956" style="margin-bottom:10px;">
  <div class="comiis_tittwo">
    <h2 class="comiis_bgoneten">��������</h2>
    <span><a href="#" taret=_blank>+������������</a></span>
  </div>
	<!--[diy=comiis_xun41]--><div id="comiis_xun41" class="area"></div><!--[/diy]-->
</div>
<!--{subtemplate common/footer}-->